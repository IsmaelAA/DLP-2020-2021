/**
 * @generated VGen (for ANTLR) 1.7.2
 */

package ast;

public interface Definition extends AST {

}
