/**
 * @generated VGen (for ANTLR) 1.7.2
 */

package ast;

import java.util.*;
import org.antlr.v4.runtime.*;

import visitor.*;

//	defStruct:definition -> name:String  definition:definition*

public class DefStruct extends AbstractDefinition {

	public DefStruct(String name, List<Definition> definition) {
		this.name = name;
		this.definition = definition;

       // Lo siguiente se puede borrar si no se quiere la posicion en el fichero.
       // Obtiene la linea/columna a partir de las de los hijos.
       setPositions(definition);
	}

	public DefStruct(Object name, Object definition) {
		this.name = (name instanceof Token) ? ((Token)name).getText() : (String) name;
		this.definition = this.<Definition>getAstFromContexts(definition);

       // Lo siguiente se puede borrar si no se quiere la posicion en el fichero.
       // Obtiene la linea/columna a partir de las de los hijos.
       setPositions(name, definition);
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public List<Definition> getDefinition() {
		return definition;
	}
	public void setDefinition(List<Definition> definition) {
		this.definition = definition;
	}

	@Override
	public Object accept(Visitor v, Object param) { 
		return v.visit(this, param);
	}

	private String name;
	private List<Definition> definition;

	public String toString() {
       return "{name:" + getName() + ", definition:" + getDefinition() + "}";
   }
}
