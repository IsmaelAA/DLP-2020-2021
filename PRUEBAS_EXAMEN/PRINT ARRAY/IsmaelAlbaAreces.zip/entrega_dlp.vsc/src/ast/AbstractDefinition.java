/**
 * @generated VGen (for ANTLR) 1.7.2
 */

package ast;

public abstract class AbstractDefinition extends AbstractAST implements Definition {

}
